#using <System.dll>

using namespace System;
using namespace System::IO;
using namespace System::Net;
using namespace System::Net::Sockets;
using namespace System::Text;
using namespace System::Threading;
void main()
{
   try
   {
      Int32 port = 23190;
      IPAddress^ lhost = IPAddress::Parse( "127.0.0.1" );
      TcpListener^ servicio = gcnew TcpListener( lhost,port );
      servicio->Start();
   }

catch ( SocketException^ e ) 
   {
      Console::WriteLine( "SocketException: {0}", e );
   }

   Console::WriteLine( "\nmal mal mal..." );
   Console::Read();
}